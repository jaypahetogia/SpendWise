package application;

public enum Screen {
	LOGIN,
	HOME,
	VIEWTRANSACTION,
	CATEGORISETRANSACTION
}
