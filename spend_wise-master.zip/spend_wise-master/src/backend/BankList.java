/**
 * 
 */
package backend;

/**
 * 
 */
public enum BankList {
KIWI,
WESTPAC,
ANZ,
BNZ
}
